
Please see https://licensedb.org/
